<?php 
	//Author: David Iacono
	//CSC 436 Database Management Systems
	//Spring 2015 DiPippo
	//Using Fellowship Technologies HTML Code Standards: http://developer.fellowshipone.com/patterns/code.php
	
	//Connect to the private connect
	include "/home/diacono/private/real_connect.php";
?>